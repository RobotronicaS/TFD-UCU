import tkinter as tk
from tkinter import ttk
import awesometkinter as atk
from tkinter import Tk
import tkinter
import tkinter.ttk
from PIL import Image, ImageTk
from tkinter import PhotoImage
import random
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
#++++++++++++++++ Ventana Principal +++++++++++++++++++++
root = tk.Tk()
root.wm_title("TFD  Ver 1.0")
root.iconbitmap(r'Logo-UCU-001-FINAL-03_ID_Uruguay.ico')
root.resizable(width=False, height=False)
root.geometry('1366x768+-8+0')
root.runTrue = 0

#+++++++++++++++++ Pestañas +++++++++++++++++++++++++++++
nb = tkinter.ttk.Notebook(root, width=1360, height=700)
nb.place(x=0, y=0)

# select tkinter theme required for things to be right on windows,
# only 'alt', 'default', or 'classic' can work fine on windows 10
style = ttk.Style()
style.theme_use('default')

# Configurando el estilo de la pestaña
style.configure('TNotebook.Tab', background='gray')


#creamos las pestañas
tab1 = tk.Frame(nb, bg='#323232')
nb.add(tab1, text=' Main ')
nb.pack(expand=1, fill='both')

tab2 = tk.Frame(nb, bg='#323232')
nb.add(tab2, text=' Eventos ')
nb.pack(expand=1, fill='both')

# Crear el primer marco
frame1 = tk.LabelFrame(tab2, width=1366, height=768, background="gray")
frame1.place(x=0, y=0)

tab3 = tk.Frame(nb, bg='#353535')
nb.add(tab3, text=' Registros ')
nb.pack(expand=1, fill='both')





# Crear el primer marco
frame1 = tk.LabelFrame(tab1, width=683, height=486, background="gray")
frame1.place(x=0, y=0)

# Cargar la imagen (asegúrate de tener una imagen "datacenter.png" en el mismo directorio que tu script)
#imagen = tk.PhotoImage(file="datacenter.png")
imagen = Image.open("datacenter.png")
# Ajustar el tamaño de la imagen a 300x300 píxeles
imagen = imagen.resize((660, 460), Image.LANCZOS)
# Convertir la imagen de Pillow a una imagen de Tkinter
imagen = ImageTk.PhotoImage(imagen)
# Crear una etiqueta con la imagen y ponerla en el marco
label = tk.Label(frame1, image=imagen)
# Posicionar la etiqueta en una ubicación específica dentro del marco
label.place(x=10, y=10)



#-------------------------------------------------------
# Crear el segundo marco
frame2 = tk.LabelFrame(tab1, width=683, height=500, background="gray")
frame2.place(x=0, y=486)

#----------------------Primer widget---------------------------------
# Crear el primer widget Frame3d y colocarlo en el marco
f1 = atk.Frame3d(frame2)
f1.config(width=110, height=110)  # Establecer el ancho a 100 y la altura a 100
f1.place(x=48, y=5)  # Ajusta estos valores según tus necesidades   
# Carga la imagen
image = PhotoImage(file="temp.png")
# Cambia el tamaño de la imagen
image = image.subsample(5, 5)  # Reduce a la mitad el tamaño de la imagen
# Crea la etiqueta con la imagen
label_1 = tk.Label(f1, image=image, bg="#333333")
label_1.image = image  # Guarda una referencia a la imagen
# Coloca la etiqueta en la ventana
label_1.place(x=30, y=10)

#----------------------Segundo widget---------------------------------
# Crear el segundo widget Frame3d y colocarlo en el marco
f2 = atk.Frame3d(frame2)
f2.config(width=110, height=110)  # Establecer el ancho a 100 y la altura a 100
f2.place(x=48, y=117)  # Ajusta estos valores según tus necesidades
# Carga la imagen
image = PhotoImage(file="hum.png")
# Cambia el tamaño de la imagen
image = image.subsample(5, 5)  # Reduce a la mitad el tamaño de la imagen
# Crea la etiqueta con la imagen
label_2 = tk.Label(f2, image=image, bg="#333333")
label_2.image = image  # Guarda una referencia a la imagen
# Coloca la etiqueta en la ventana
label_2.place(x=30, y=10)


#----------------------Tercer widget---------------------------------
f3 = atk.Frame3d(frame2)
f3.config(width=110, height=110)  # Establecer el ancho a 100 y la altura a 100
f3.place(x=206, y=5)  # Ajusta estos valores según tus necesidades
# Carga la imagen
image = PhotoImage(file="tempamb.png")
# Cambia el tamaño de la imagen
image = image.subsample(5, 5)  # Reduce a la mitad el tamaño de la imagen
# Crea la etiqueta con la imagen
label_3 = tk.Label(f3, image=image, bg="#333333")
label_3.image = image  # Guarda una referencia a la imagen
# Coloca la etiqueta en la ventana
label_3.place(x=30, y=10)

#----------------------Cuarto widget---------------------------------
# Crear el segundo widget Frame3d y colocarlo en el marco
f4 = atk.Frame3d(frame2)
f4.config(width=110, height=110)  # Establecer el ancho a 100 y la altura a 100
f4.place(x=206, y=117)  # Ajusta estos valores según tus necesidades
# Carga la imagen
image = PhotoImage(file="fuego.png")
# Cambia el tamaño de la imagen
image = image.subsample(3, 3)  # Reduce a la mitad el tamaño de la imagen
# Crea la etiqueta con la imagen
label_4 = tk.Label(f4, image=image, bg="#333333")
label_4.image = image  # Guarda una referencia a la imagen
# Coloca la etiqueta en la ventana
label_4.place(x=30, y=10)


#----------------------Quinto widget---------------------------------
# Crear el primer widget Frame3d y colocarlo en el marco
f5 = atk.Frame3d(frame2)
f5.config(width=110, height=110)  # Establecer el ancho a 100 y la altura a 100
f5.place(x=364, y=5)  # Ajusta estos valores según tus necesidades
# Carga la imagen
image = PhotoImage(file="enchufe.png")
# Cambia el tamaño de la imagen
image = image.subsample(4, 4)  # Reduce a la mitad el tamaño de la imagen
# Crea la etiqueta con la imagen
label_5 = tk.Label(f5, image=image, bg="#333333")
label_5.image = image  # Guarda una referencia a la imagen
# Coloca la etiqueta en la ventana
label_5.place(x=30, y=10)

#----------------------Sexto widget---------------------------------
# Crear el segundo widget Frame3d y colocarlo en el marco
f6 = atk.Frame3d(frame2)
f6.config(width=110, height=110)  # Establecer el ancho a 100 y la altura a 100
f6.place(x=364, y=117)  # Ajusta estos valores según tus necesidades
# Carga la imagen
image = PhotoImage(file="puertaentrada.png")
# Cambia el tamaño de la imagen
image = image.subsample(2, 2)  # Reduce a la mitad el tamaño de la imagen
# Crea la etiqueta con la imagen
label_6 = tk.Label(f6, image=image, bg="#333333")
label_6.image = image  # Guarda una referencia a la imagen
# Coloca la etiqueta en la ventana
label_6.place(x=30, y=10)

#----------------------Septimo widget---------------------------------
# Crear el primer widget Frame3d y colocarlo en el marco
f7 = atk.Frame3d(frame2)
f7.config(width=110, height=110)  # Establecer el ancho a 100 y la altura a 100
f7.place(x=522, y=5)  # Ajusta estos valores según tus necesidades
# Carga la imagen
image = PhotoImage(file="puertadata.png")
# Cambia el tamaño de la imagen
image = image.subsample(4, 4)  # Reduce a la mitad el tamaño de la imagen
# Crea la etiqueta con la imagen
label_7 = tk.Label(f7, image=image, bg="#333333")
label_7.image = image  # Guarda una referencia a la imagen
# Coloca la etiqueta en la ventana
label_7.place(x=30, y=10)

#----------------------Octavo widget---------------------------------
# Crear el segundo widget Frame3d y colocarlo en el marco
f8 = atk.Frame3d(frame2)
f8.config(width=110, height=110)  # Establecer el ancho a 100 y la altura a 100
f8.place(x=522, y=117)  # Ajusta estos valores según tus necesidades
# Carga la imagen
image = PhotoImage(file="canilla.png")
# Cambia el tamaño de la imagen
image = image.subsample(2, 2)  # Reduce a la mitad el tamaño de la imagen
# Crea la etiqueta con la imagen
label_8 = tk.Label(f8, image=image, bg="#333333")
label_8.image = image  # Guarda una referencia a la imagen
# Coloca la etiqueta en la ventana
label_8.place(x=30, y=10)

#-------------------------------------------------------
# Crear el tercer marco
frame2 = tk.LabelFrame(tab1, width=683, height=768, background="gray")
frame2.place(x=683, y=0)

#-------------------------------------------------------
# Crear gráficos 1
# Crear una figura de matplotlib y cuatro subgráficos
fig, axs = plt.subplots(4, figsize=(7, 36/5))
# Cambiar los límites de los ejes para cada subgráfico
for ax in axs:
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 70)
    ax.tick_params(axis='x', colors='white')  # Cambia el color de los números del eje x a white
    ax.tick_params(axis='y', colors='white')  # Cambia el color de los números del eje y a white

# Crear un canvas de matplotlib y añadirlo a la ventana de Tkinter
canvas = FigureCanvasTkAgg(fig, master=frame2)
canvas.get_tk_widget().pack()

# Crear cuatro listas para almacenar los datos de las variables analógicas
datos_analogicos = [[], [], [], []]


#-------------------------------------------------------
def actualizar_valor():
    # Genera un número aleatorio entre 0 y 1000
    # Supongamos que este es tu valor analógico
    valor_analogico_1 = random.uniform(45,50)
    valor_analogico_2 = random.uniform(45,50)
    valor_analogico_3 = random.uniform(45,50)
    valor_analogico_4 = random.uniform(45,50)
    valor_digital_5 = random.randint(0,1)
    valor_digital_6 = random.randint(0,1)
    valor_digital_7 = random.randint(0,1)
    valor_digital_8 = random.randint(0,1)
    # Redondea el número a una cifra decimal
    valor_analogico_1 = round(valor_analogico_1, 1)
    valor_analogico_2 = round(valor_analogico_2, 1)
    valor_analogico_3 = round(valor_analogico_3, 1)
    valor_analogico_4 = round(valor_analogico_4, 1)
    
    # Crear una etiqueta con el valor analógico y ponerla en el marco
    label_1 = tk.Label(f1, text=str(valor_analogico_1), font=("Arial", 14), bg="#333333", fg="#00BF00")
    label_1.place(x=35, y=70)
    label_2 = tk.Label(f2, text=str(valor_analogico_2), font=("Arial", 14), bg="#333333", fg="#00BF00")
    label_2.place(x=35, y=70)
    label_3 = tk.Label(f3, text=str(valor_analogico_3), font=("Arial", 14), bg="#333333", fg="#00BF00")
    label_3.place(x=35, y=70)
    label_4 = tk.Label(f4, text=str(valor_analogico_4), font=("Arial", 14), bg="#333333", fg="#00BF00")
    label_4.place(x=35, y=70)

    # Crear la etiqueta 5 una vez
    label_5 = tk.Label(f5, font=("Arial", 14), bg="#333333")
    # Colocar la etiqueta en la ventana
    label_5.place(x=25, y=70)
    # Luego, en tu código donde cambias el valor de 'valor_digital_5', simplemente cambia el texto de la etiqueta
    if valor_digital_5 == 1:
        label_5.config(text="¡Error!  ", fg="#E50000")
    else:
        label_5.config(text="Nominal", fg="#00BF00")

    # Crear la etiqueta 6 una vez
    label_6 = tk.Label(f6, font=("Arial", 14), bg="#333333")
    # Colocar la etiqueta en la ventana
    label_6.place(x=25, y=70)
    # Luego, en tu código donde cambias el valor de 'valor_digital_5', simplemente cambia el texto de la etiqueta
    if valor_digital_6 == 1:
        label_6.config(text="¡Abierto!", fg="#E50000")
    else:
        label_6.config(text="Cerrado", fg="#00BF00")
    
    # Crear la etiqueta 7 una vez
    label_7 = tk.Label(f7, font=("Arial", 14), bg="#333333")
    # Colocar la etiqueta en la ventana
    label_7.place(x=20, y=70)
    # Luego, en tu código donde cambias el valor de 'valor_digital_5', simplemente cambia el texto de la etiqueta
    if valor_digital_7 == 1:
        label_7.config(text="¡Abierto!", fg="#E50000")
    else:
        label_7.config(text="Cerrado", fg="#00BF00")
    
    # Crear la etiqueta 8 una vez
    label_8 = tk.Label(f8, font=("Arial", 14), bg="#333333")
    # Colocar la etiqueta en la ventana
    label_8.place(x=20, y=70)
    # Luego, en tu código donde cambias el valor de 'valor_digital_5', simplemente cambia el texto de la etiqueta
    if valor_digital_8 == 1:
        label_8.config(text="¡Descon!", fg="#E50000")
    else:
        label_8.config(text=" Activo     ", fg="#00BF00")
        
    # Actualiza la etiqueta con el nuevo valor
    label_1.config(text=str(valor_analogico_1))
    label_2.config(text=str(valor_analogico_2))
    label_3.config(text=str(valor_analogico_3))
    label_4.config(text=str(valor_analogico_4))
    

    # Añadir valores a las listas
    for i in range(4):
        datos_analogicos[i].append(eval(f'valor_analogico_{i+1}'))

    # Definir una lista de colores
    colores_graficos = ['blue', 'green', 'red', 'cyan']
    colores_fondo = ['#000000', '#000000', '#000000', '#000000']

    # Limpiar los subgráficos y dibujar los nuevos datos con colores diferentes y fondos diferentes
    for i, ax in enumerate(axs):
        ax.clear()
        ax.plot(datos_analogicos[i], color=colores_graficos[i])
        ax.set_facecolor(colores_fondo[i])
        # Agregar líneas horizontales y verticales para cada valor de los ejes
        for x in range(101):  # Asume que el eje x va de 0 a 100
            ax.axvline(x=x, color='white', linestyle='--', linewidth=0.15)
        for y in range(71):  # Asume que el eje y va de 0 a 70
            ax.axhline(y=y, color='white', linestyle='--', linewidth=0.15)
        # Cambiar el color de fondo de la figura completa
        fig.patch.set_facecolor('#171717')
        # Actualizar el canvas de matplotlib
        canvas.draw()
    # Programa la próxima actualización para dentro de 1 segundo (1000 milisegundos)
    root.after(3000,actualizar_valor)
   
    
    


    


   
    


# Inicia la actualización
actualizar_valor()
root.mainloop()

